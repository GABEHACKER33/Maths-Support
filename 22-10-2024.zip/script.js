function showGame(gameId) {
    const gameContainer = document.getElementById('game-container');
    const iframeContainer = document.getElementById('iframeContainer');
    const gameButtons = document.getElementById('game-buttons');
    const logoContainer = document.getElementById('logo-container');
    
    // Definición de URLs de los juegos
    const gameUrls = {
        '1v1': 'https://www.astracraftgame.com/en/',
        'slither': 'https://slither.io/',
        'krunker': 'https://krunker.io/?game=FRA:rjfzp',
        'Shell Shockers': 'https://kevin.games/shellshock-io',
        'Squid Game': 'https://squid-game.io',
        'Agar.io': 'https://agar.io',
        'ZombsRoyale': 'https://zombsroyale.io',
        'Paper.io': 'https://gameforge.com/en-US/littlegames/snowball-io/',
        'SuperHex.io': 'https://superhex.io',
        'Pacman': 'https://freepacman.org/',
        'Tetris': 'https://tetris.com/play-tetris',
        'Vectaria.io': 'https://vectaria.io/',
        'Geometry Dash': 'https://femoi.dk/geometry-dash/',
        'Snake': 'https://littlebigsnake.com',
        'Proximos Juegos': 'https://docs.google.com/forms/d/e/1FAIpQLSca0M7eMosYMhJCjllf7rofHe0VK9qKkAV3OaQusgj15wzxGA/viewform?embedded=true'
    };

    // Configuración del iframe
    iframeContainer.innerHTML = `<iframe src="${gameUrls[gameId]}" style="width:100%; height:500px; border:none;"></iframe>`;

    // Mostrar el contenedor del juego y ocultar los botones
    gameContainer.style.display = 'block';
    gameButtons.style.display = 'none';

    // Ocultar el logo de Maths Support
    logoContainer.style.opacity = 0;
}

function exitGame() {
    // Refrescar la página
    location.reload();
    
    // También ocultar el contenedor del juego y mostrar los botones de juegos
    document.getElementById('game-container').style.display = 'none';
    document.getElementById('game-buttons').style.display = 'flex';

    // Restablecer el logo y mostrarlo de nuevo
    document.getElementById('logo-container').style.opacity = 1;
}

function toggleFullscreen() {
    const iframe = document.querySelector('#iframeContainer iframe');
    if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
    } else if (iframe.mozRequestFullScreen) { // Firefox
        iframe.mozRequestFullScreen();
    } else if (iframe.webkitRequestFullscreen) { // Chrome, Safari y Opera
        iframe.webkitRequestFullscreen();
    } else if (iframe.msRequestFullscreen) { // IE/Edge
        iframe.msRequestFullscreen();
    }
}
